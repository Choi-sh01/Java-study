package task1;

public class Typecasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		final int num1 = 10, num2 = 20;
		
		double result = (double)num1/num2;
		
		System.out.println(result);
	}

}
